/** Automatically generated file. DO NOT MODIFY */
package pro.projectlazer2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}