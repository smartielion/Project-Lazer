package pro.projectlazer2;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;

public class GameEnd extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about_page);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}
	
	@Override
	public void onBackPressed(){
		setContentView(R.layout.activity_main_screen);
		
	}
	
	public void returnPush(View V){
		setContentView(R.layout.activity_main_screen);
	}

}

