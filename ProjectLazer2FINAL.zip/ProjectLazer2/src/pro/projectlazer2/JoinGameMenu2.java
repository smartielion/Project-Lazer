package pro.projectlazer2;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;

public class JoinGameMenu2 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_join_game_menu2);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}
	
	@Override
	public void onBackPressed(){
		//returns to the home screen
		setContentView(R.layout.activity_join_game_menu2);
	}
	
	public void joinGamefromJGMenu(View v){
    	//set intent
    	setContentView(R.layout.activity_active_state);
    	
    }

}
