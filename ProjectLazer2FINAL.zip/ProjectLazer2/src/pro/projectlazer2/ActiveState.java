package pro.projectlazer2;

import java.util.Random;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class ActiveState extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_active_state);
	}
    

	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}
	
	@Override
	public void onBackPressed(){
		//returns to the home screen
		setContentView(R.layout.activity_active_state);
	}
	
/*	public void fire(){
		//shots the lazer
		Random randGen = new Random();
		float randX = randGen.nextFloat();
		randX = randX * 100;
		if ((int)randX < 40){
			//user has been hit(simulated, enter active state
			//set up intent
			setContentView(R.layout.activity_dead_state);
		}
	}
*/
}

