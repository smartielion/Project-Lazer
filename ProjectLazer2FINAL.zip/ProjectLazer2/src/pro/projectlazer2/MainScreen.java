package pro.projectlazer2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Date;
import java.util.Random;

import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Vibrator;
import android.os.CountDownTimer;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.view.Window;
import android.widget.ProgressBar;


public class MainScreen extends Activity {
	String myName = "I am Ledgend";
	String gameName = "Default Game";
	double gameEnd; //change to a datetime class
	int gameDur;
	int p = 0; //Temporary value to kill you after a few clicks
	int numPlayers = 0;
	double myLat = 0.0;
	double myLon = 0.0;
	String playerList[] = new String[100];//Caps max players at 100(can be changed)
	double latList[] = new double[100];
	double lonList[] = new double[100];
	String killedByList[] = new String[100]; //if you have something here, you are dead and deserved it
	int scoreList[] = new int[100];
	getCompass getComp = new getCompass();
    private Button white;
    private SoundPool spool;
    public int laserSound;
    public int pageTurn;
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main_screen);
        getComp.m_sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        getComp.registerListeners();
        this.setVolumeControlStream(AudioManager.STREAM_MUSIC);
        spool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        pageTurn = spool.load(this, R.raw.laserbeam, 1);
        laserSound = spool.load(this, R.raw.lasershot, 1);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch(item.getItemId()){
    	case R.id.quit:
    		//stops the app from running
    		finish();

    	case R.id.help:
    		setContentView(R.layout.activity_help_page);
    		return true;
    		//takes the users to the settings page to modify their stuff
    	case R.id.home:
    		 setContentView(R.layout.activity_main_screen);
    		 return true;
    	case R.id.about:
    		setContentView(R.layout.activity_about_page);
    		return true;
    	}
    	return true;
    }
    
    public void nextPush(View V){
		setContentView(R.layout.activity_help_page2);
	}
    
    public void returnPush(View V){
		setContentView(R.layout.activity_main_screen);
	}
    
    public void joinGame(View v) {
    	Sound(pageTurn);
    	//Intent joinIntent = new Intent(this,ActiveState.class);
        setContentView(R.layout.activity_join_game_menu2);
        //set game name and player name, update
    }
 
    public void hostGame(View v){
    	Sound(pageTurn);
    	setContentView(R.layout.activity_host_game_menu2);
    	
    }
	@Override
	public void onBackPressed(){
		//returns to the home screen
	}
	
    public void joinGameH(View v) throws IOException{
    	//set intent
    	Sound(pageTurn);
		EditText nameTxt = (EditText) findViewById(R.id.hostMyNametxt);

		myName = nameTxt.getText().toString();
		EditText gameTxt = (EditText) findViewById(R.id.hostGameGameNametxt);

		gameName = gameTxt.getText().toString();
		EditText durTxt = (EditText) findViewById(R.id.joinGameGameLengthtxt);

    	getComp.m_sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        getComp.registerListeners();
		gameDur = Integer.parseInt((durTxt.getText().toString()));
    	//joins game from host game menu
		serverAction(5,null,myLat,myLon);
		setContentView(R.layout.activity_active_state);
    }
    
    public void Sound(int soundID){
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        float volume = (float) audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        spool.play(soundID, volume, volume, 1, 0, 1f);
    }
    
    public void hostHome(View v){
    	//set intent
    	Sound(pageTurn);
    	setContentView(R.layout.activity_main_screen);
    	
    }
    
	public void joinGamefromJGMenu(View v) throws IOException{
    	//set intent
		Sound(pageTurn);
		EditText nameTxt = (EditText) findViewById(R.id.hostGameGameNametxt);

		myName = nameTxt.getText().toString();
		EditText gameTxt = (EditText) findViewById(R.id.joinGameGameLengthtxt);

		gameName = gameTxt.getText().toString();
		//Joins game form Join game menu
		serverAction(4,null,myLat,myLon);
    	setContentView(R.layout.activity_active_state);
    	
    }
	
	//Countdown timer for shot cooldown progress bar
	public void fireDelay(){
		final ProgressBar myProgressBar;
		CountDownTimer myCountDownTimer;
		final long length =  (long) 5000.0;
		final long period = (long) 500.0; 
		
		myProgressBar=(ProgressBar)findViewById(R.id.shotCooldownBar);
		myProgressBar.setProgress(0);
		myProgressBar.setMax(100);
		myCountDownTimer =new CountDownTimer(length, period){
			int i = 0;
		
			@Override
			public void onTick(long millisUntilFinished_){
				Button fireButton = (Button)findViewById(R.id.FireButton);
				fireButton.setEnabled(false);
				i += 10;// (5000-millisUntilFinished_);
				myProgressBar.setProgress(i);
			}
			
			@Override
			public void onFinish(){
				myProgressBar.setProgress((i+=10));
				Button fireButton = (Button)findViewById(R.id.FireButton);
				fireButton.setEnabled(true);
				
				try {
					serverAction(1,"" , myLat, myLon);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return;
			}
		};
		myCountDownTimer.start();
	}
	
	public void onDead(){
		Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		// Vibrate for 500 milliseconds
		vibe.vibrate(500);
		setContentView(R.layout.activity_dead_state);
		
		final ProgressBar myProgressBar;
		CountDownTimer myCountDownTimer;
		final long length =  (long) 20000.0;  //death timer of 20 seconds
		final long period = (long) 2000.0; 
		
		myProgressBar=(ProgressBar)findViewById(R.id.deadStateBar);
		myProgressBar.setProgress(0);
		myProgressBar.setMax(100);
		myCountDownTimer =new CountDownTimer(length, period){
			int i = 0;
		
			@Override
			public void onTick(long millisUntilFinished_){
				i += 10;
				myProgressBar.setProgress(i);
			}
			
			@Override
			public void onFinish(){
				myProgressBar.setProgress((i+=10));
				try {
					serverAction(2, "", myLat, myLon);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  //Server Call to Respawn
				setContentView(R.layout.activity_active_state);

			}
		};
		myCountDownTimer.start();
	}
	
	public void fire(View v) throws IOException{
		Sound(laserSound);
         
		String hitEnemy = "Worse Player";
		double myLat = 0.0;
		double myLon = 0.0;
	
		//Omni kill function which only works if your name is Katniss
		if (myName == "katniss"){
			for (int i = 0; playerList[i] != null ; i++){
				if (playerList[i] != "katniss")
					serverAction(0, playerList[i], myLat, myLon);
			}
		}//Should maybe take this section out at final release...
		
		else{  //if you are not Katniss, do lots of shit:
		
		GPSTracker gps = new GPSTracker(this);

		// check if GPS enabled     
		if(gps.canGetLocation()){
		    myLat= gps.getLatitude();
		    myLon = gps.getLongitude();
		}else{
		// can't get location
		// GPS or Network is not enabled
		// Ask user to enable GPS/network in settings
		    gps.showSettingsAlert();   
		}
		boolean hit = false; //checks to see if there's at least one hit
		double possVictims[] = new double[100];    //array of possible victims
		for(int i = 0; playerList[i] != null; i++){ 
			//find players within 160 feet
			double distance = distanceBetween(myLat, myLon, latList[i], lonList[i]);
			if((distance*0.000434) <= 160){
				possVictims[i] = distance;
				hit = true;
			}
		}
		
		if(hit == false) {//update server with no hit}
			serverAction(1,hitEnemy, myLat, myLon);
		}
		else{
			float compass[] = new float[3]; //make float to hold return values
			compass = getComp.computeOrientation();
			float degree = compass[0]; //this value should be the degree that determines compass direction
			for(int i = 0; playerList[i] != null; i++){   
				if ( myName != playerList[i]){
					double lat = latList[i]; //holds lat and lon values of other players
					double lon = lonList[i];
					double mydegree = Math.abs(Math.atan((myLon - lon)/(myLat - lat))); //determines angle
					if((myLat < lat) && (myLon < lon)){ //pos x,y
						mydegree = 90 - mydegree;
					}
					else if((myLat < lat) && (myLon > lon)){ //pos x, neg y
						mydegree = 180 - mydegree;
					}
					else if((myLat > lat) && (myLon < lon)){ //neg x, pos y
						mydegree = -(90 - mydegree);
					}
					else if((myLat > lat) && (myLon > lon)){ //neg x, neg y
						mydegree = -(180 - mydegree);
					}
					if ((mydegree > degree -5) || (mydegree < degree + 5) ){ //compare with found angle within +- 5 degrees
						continue;
					}
					else { possVictims[i] = 10000000;} //if not within angle, 'remove' from possible victims
				}
			}
		}
		//Find closest player, especially if there is more than one in angle
		double small = 1000000;
		int n = -1;
		for(int i = 0; playerList[i] != null; i++){
			if(possVictims[i] < small){
				small = possVictims[i];
				n = i;
			}
		}
		
		
		if ( n != -1){  //shot was a hit
			serverAction(0, playerList[n], myLat, myLon);
		}
		else{	//Shot was a miss
			serverAction(1, null, myLat, myLon);
		}
		
		}//end of else( not Katniss)
				
		fireDelay(); //Shot cooldown bar
	}//End of Fire
	
	public double distanceBetween(double myLat, double myLon, double lat, double lon){
		double distance;
		distance =(myLat - lat)*(myLat - lat) + (myLon - lon)*(myLon - lon);
		distance = Math.sqrt(distance);
		return distance;
	}
	
	public int indexOfString(String[] strArr, String findMe){
		for (int i = 0;i<strArr.length;i++){
			if (findMe.equals(strArr[i])){
				return i;
			}
		}
		return -1;
	}
	
	public int addPlayer(String name){
		//inserts player in last possible spot in array
		for (int j = 0;j>100;j++){
			if (playerList[j] != null){
				playerList[j]= name;
				return j;
			}
			
		}
		return -1;
	}
	
	void serverAction(int action, String hitEnemy, double mylat, double mylon) throws IOException{
		/*ALL ACTIONS NEED:
		 *  Game name
		 *  Lat
		 *  Lon
		*/
		if (action == 0){
			//FIRE ACTION (needs my name, yourname)
			URL hitURL = new URL("http://thumper.net/smartielion/hit.php");

			String result = "";
			String postData = "myName=" + myName + "&yourName=" + hitEnemy + "&myLat=" + mylat + "&myLon="+mylon + "&gameName="+ gameName;
			HttpURLConnection hitConnection = (HttpURLConnection) hitURL.openConnection();
			hitConnection.setDoInput(true);
			hitConnection.setDoOutput(true);
			hitConnection.setUseCaches(false);
			hitConnection.setRequestMethod("POST");
			hitConnection.setRequestProperty("Content-Type",
	                "application/x-www-form-urlencoded");
			
	        DataOutputStream dataOut = new DataOutputStream(
	                hitConnection.getOutputStream());
	        dataOut.writeBytes(postData);
	        dataOut.flush();
	        DataInputStream in = new DataInputStream (hitConnection.getInputStream ());
			

	        String g;
	        g = in.readLine();
	        //numPlayers = Integer.parseInt(g);
	        int playerspot = 0;
	        while ((g = in.readLine()) != null) {
	       	 g.replaceAll("\\<.*?>","");
		        String[] split = g.split(" ");
		        if (split[1].equals("Error")){
		        	
		        }
		        else{
		        	playerspot = indexOfString(playerList,split[0]);
		        	if (playerspot ==-1){
		        		playerspot = addPlayer(split[0]);
		        	}
		        	latList[playerspot]=Double.parseDouble(split[2]);
		        	lonList[playerspot]=Double.parseDouble(split[3]);
		        	scoreList[playerspot]=Integer.parseInt(split[4]);
		        	killedByList[playerspot]=split[5];
		        }
	        }
	        in.close();
	        
	        if (killedByList[playerspot] != ""){  //if there is something in killedby, then die
        		onDead();
        	}
	        //PARSE RETURN VALUES INTO ARRAYS
		}
		else if(action ==1){
			//Update ACTION(needs my name)
			URL hitURL = new URL("http://thumper.net/smartielion/update.php");

			String result = "";
			String postData = "myName=" + myName +  "&myLat=" + mylat + "&myLon="+mylon + "&gameName="+ gameName;
			HttpURLConnection hitConnection = (HttpURLConnection) hitURL.openConnection();
			hitConnection.setDoInput(true);
			hitConnection.setDoOutput(true);
			hitConnection.setUseCaches(false);
			hitConnection.setRequestMethod("POST");
			hitConnection.setRequestProperty("Content-Type",
	                "application/x-www-form-urlencoded");
			
	        DataOutputStream dataOut = new DataOutputStream(
	                hitConnection.getOutputStream());
	        dataOut.writeBytes(postData);
	        dataOut.flush();
	        DataInputStream in = new DataInputStream (hitConnection.getInputStream ());
			

	        String g;
	        g = in.readLine();
	        ////numPlayers = Integer.parseInt(g);
	        int playerspot = 0;
	        while ((g = in.readLine()) != null) {
	       	 g.replaceAll("\\<.*?>","");
		        String[] split = g.split(" ");
		        if (split[1].equals("Error")){
		        	
		        }
		        else{
		        	playerspot = indexOfString(playerList,split[0]);
		        	if (playerspot ==-1){
		        		playerspot = addPlayer(split[0]);
		        	}
		        	latList[playerspot]=Double.parseDouble(split[2]);
		        	lonList[playerspot]=Double.parseDouble(split[3]);
		        	scoreList[playerspot]=Integer.parseInt(split[4]);
		        	killedByList[playerspot]=split[5];
		        	
		        	
		        }
	        }
	        in.close();
	        
	        if (killedByList[playerspot] != ""){  //if there is something in killedby, then die
        		onDead();
        	}
	        //PARSE RETURN VALUES INTO ARRAYS
	    }
		else if(action ==2){
			//RESPAWN ACTION(Needs my name)
			URL hitURL = new URL("http://thumper.net/smartielion/respawn.php");

			String result = "";
			String postData = "myName=" + myName + "&myLat=" + mylat + "&myLon="+mylon + "&gameName="+ gameName;
			HttpURLConnection hitConnection = (HttpURLConnection) hitURL.openConnection();
			hitConnection.setDoInput(true);
			hitConnection.setDoOutput(true);
			hitConnection.setUseCaches(false);
			hitConnection.setRequestMethod("POST");
			hitConnection.setRequestProperty("Content-Type",
	                "application/x-www-form-urlencoded");
			
	        DataOutputStream dataOut = new DataOutputStream(
	                hitConnection.getOutputStream());
	        dataOut.writeBytes(postData);
	        dataOut.flush();
	        DataInputStream in = new DataInputStream (hitConnection.getInputStream ());
			

	        String g;
	        g = in.readLine();
	        ////numPlayers = Integer.parseInt(g);
	        while ((g = in.readLine()) != null) {
	        	 g.replaceAll("\\<.*?>","");
		        String[] split = g.split(" ");
		        if (split[1].equals("Error")){
		        	
		        }
		        else{
		        	String incName = split[0];
		        	int playerspot = indexOfString(playerList,incName);
		        	if (playerspot ==-1){
		        		playerspot = addPlayer(incName);
		        	}
		        	latList[playerspot]=Double.parseDouble(split[2]);
		        	lonList[playerspot]=Double.parseDouble(split[3]);
		        	scoreList[playerspot]=Integer.parseInt(split[4]);
		        	killedByList[playerspot]=split[5];
		        }
	        }
	        in.close();
	        
	        //PARSE RETURN VALUES INTO ARRAYS
	    }
		else if(action ==3){
			//CLOSE GAME ACTION
			URL hitURL = new URL("http://thumper.net/smartielion/killgame.php");

			String result = "";
			String postData = "gameName="+ gameName;
			HttpURLConnection hitConnection = (HttpURLConnection) hitURL.openConnection();
			hitConnection.setDoInput(true);
			hitConnection.setDoOutput(true);
			hitConnection.setUseCaches(false);
			hitConnection.setRequestMethod("POST");
			hitConnection.setRequestProperty("Content-Type",
	                "application/x-www-form-urlencoded");
			
	        DataOutputStream dataOut = new DataOutputStream(
	                hitConnection.getOutputStream());
	        dataOut.writeBytes(postData);
	        dataOut.flush();
	        DataInputStream in = new DataInputStream (hitConnection.getInputStream ());
			

	        String g;
	        g = in.readLine();
	        //numPlayers = Integer.parseInt(g);
	        while ((g = in.readLine()) != null) {
	       	 g.replaceAll("\\<.*?>","");
		        String[] split = g.split(" ");
		        if (split[1].equals("Error")){
		        	
		        }
		        else{
		        	int playerspot = indexOfString(playerList,split[0]);
		        	if (playerspot ==-1){
		        		playerspot = addPlayer(split[0]);
		        	}
		        	latList[playerspot]=Double.parseDouble(split[2]);
		        	lonList[playerspot]=Double.parseDouble(split[3]);
		        	scoreList[playerspot]=Integer.parseInt(split[4]);
		        	killedByList[playerspot]=split[5];
		        }
	        }
	        in.close();
	        
	        //PARSE RETURN VALUES INTO ARRAYS
		}	  
	    else if (action ==4){
	    	//JOIN GAME ACTION
			URL hitURL = new URL("http://thumper.net/smartielion/joingame.php");

			String result = "";
			String postData = "myName=" + myName + "&myLat=" + mylat + "&myLon="+mylon + "&gameName="+ gameName;
			HttpURLConnection hitConnection = (HttpURLConnection) hitURL.openConnection();
			hitConnection.setDoInput(true);
			hitConnection.setDoOutput(true);
			hitConnection.setUseCaches(false);
			hitConnection.setRequestMethod("POST");
			hitConnection.setRequestProperty("Content-Type",
	                "application/x-www-form-urlencoded");
			
	        DataOutputStream dataOut = new DataOutputStream(
	                hitConnection.getOutputStream());
	        dataOut.writeBytes(postData);
	        dataOut.flush();
	        DataInputStream in = new DataInputStream (hitConnection.getInputStream ());
			

	        String g;
	        
	        g = in.readLine();
	      //gameEnd = Double.parseDouble(g);
	        g = in.readLine();
	        //numPlayers = Integer.parseInt(g);
	        while ((g = in.readLine()) != null) {
	       	 g.replaceAll("\\<.*?>","");
		        String[] split = g.split(" ");
		        if (split[1].equals("Error")){
		        	
		        }
		        else{
		        	int playerspot = indexOfString(playerList,split[0]);
		        	if (playerspot ==-1){
		        		playerspot = addPlayer(split[0]);
		        	}
		        	latList[playerspot]=Double.parseDouble(split[2]);
		        	lonList[playerspot]=Double.parseDouble(split[3]);
		        	scoreList[playerspot]=Integer.parseInt(split[4]);
		        	killedByList[playerspot]=split[5];
		        }
	        }
	        in.close();
	        
	        //PARSE RETURN VALUES INTO ARRAYS
	    }
	    else if (action ==5){
	    	//HOST GAME ACTION
			URL hitURL = new URL("http://thumper.net/smartielion/makegame.php");

			String result = "";
			String postData = "myName=" + myName + "&myLat=" + mylat + "&myLon="+mylon + "&gameName="+ gameName + "&gameDur=" + gameDur;
			HttpURLConnection hitConnection = (HttpURLConnection) hitURL.openConnection();
			hitConnection.setDoInput(true);
			hitConnection.setDoOutput(true);
			hitConnection.setUseCaches(false);
			hitConnection.setRequestMethod("POST");
			hitConnection.setRequestProperty("Content-Type",
	                "application/x-www-form-urlencoded");
			
	        DataOutputStream dataOut = new DataOutputStream(
	                hitConnection.getOutputStream());
	        dataOut.writeBytes(postData);
	        dataOut.flush();
	        DataInputStream in = new DataInputStream (hitConnection.getInputStream ());
			

	        String g;
	        g = in.readLine();
	        //gameEnd = Double.parseDouble(g);
	        g = in.readLine();
	        ////numPlayers = Integer.parseInt(g);
	        while ((g = in.readLine()) != null)
	        {
	        	g.replaceAll("\\<.*?>","");
		        String[] split = g.split(" ");
		        	int playerspot = indexOfString(playerList,split[0]);
		        	if (playerspot ==-1){
		        		playerspot = addPlayer(split[0]);
		        	}
		        	latList[playerspot]=Double.parseDouble(split[2]);
		        	lonList[playerspot]=Double.parseDouble(split[3]);
		        	scoreList[playerspot]=Integer.parseInt(split[4]);
		        	killedByList[playerspot]=split[5];
		        
	        }
	        in.close();
	        
	        //PARSE RETURN VALUES INTO ARRAYS
	    
	    }
	    else if (action==6)
	    {
	    	//PLAYER LEAVING ACTION
	    	URL hitURL = new URL("http://thumper.net/smartielion/leavegame.php");
			String result = "";
			String postData = "myName=" + myName + "&gameName="+ gameName;
			HttpURLConnection hitConnection = (HttpURLConnection) hitURL.openConnection();
			hitConnection.setDoInput(true);
			hitConnection.setDoOutput(true);
			hitConnection.setUseCaches(false);
			hitConnection.setRequestMethod("POST");
			hitConnection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
	        DataOutputStream dataOut = new DataOutputStream(hitConnection.getOutputStream());
	        dataOut.writeBytes(postData);
	        dataOut.flush();
	        DataInputStream in = new DataInputStream (hitConnection.getInputStream ());	
	        in.close();
	        //PARSE RETURN VALUES INTO ARRAYS
	    }  
	}
}
